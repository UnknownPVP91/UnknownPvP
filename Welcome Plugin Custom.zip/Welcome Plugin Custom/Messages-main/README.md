# Reqid7 Join/leave messages
#Edit in Config.yml

Included: First-Join (Broadcast) Join (Broadcast) leave (Broadcast) Death-Message (Broadcast)

First-Join (Player Message) Join (Player Message)
